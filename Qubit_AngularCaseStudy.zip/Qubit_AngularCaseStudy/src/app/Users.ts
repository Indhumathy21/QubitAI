export class Users
{
    id:number;
    firstname:string;
    lastname:string;
  //  bu:string;
    email:string

    constructor(id,firstname,lastname,bu,email)
    {
        this.id = id;
        this.firstname = firstname;
        this.lastname = lastname;
    //    this.bu=bu;
        this.email=email;

    }
}
