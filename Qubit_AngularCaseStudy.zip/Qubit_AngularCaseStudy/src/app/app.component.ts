import {Component ,OnInit} from '@angular/core';
import {RestService} from './rest.service';
import {Users} from './Users';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title="Application";
private sortingorder;
    constructor(private rs : RestService) { }
// columns = ["User Id","First Name","Last Name"];
index = ["id", "firstName", "lastName","bu","email"];

users : Users[] = [];
columnDefs = [
     {headerName: 'User Id', field: 'id' },
     {headerName: 'First Name', field: 'firstName'},
     {headerName: 'Last Name', field: 'lastName'},
  //   {headerName: 'BU', field: 'bu'},
     {headerName: 'Email', field: 'email'},

 ];


 gridOptions: {
    pagination: true,
    pageLength: 5
}



   ngOnInit(): void {

      this.rs.getUsers().subscribe
       (
       (response)=>
         {
           this.users = response;
           console.log("this.users",this.users);
         },
         (error) => console.log(error)
        )
     }
}
